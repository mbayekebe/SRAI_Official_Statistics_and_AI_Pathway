# Kintaba Evidence Register Data Dictionary

## Dataset purpose

The register supplies ten synthetic evidence records for the Module OS-A01 practical work. Learners use the records to distinguish source-backed statements from AI-generated candidates, map institutional roles and information flows, identify evidence gaps, and document verification decisions.

The register is deliberately small. It supports controlled learning and reproducible notebook execution; it is not intended to represent a complete national statistical system.

| Field | Type | Required | Meaning | Validation rule |
|---|---|---:|---|---|
| `evidence_id` | string | Yes | Stable identifier for one evidence record. | Unique and formatted as `E` followed by two digits. |
| `source` | string | Yes | Synthetic title of the originating instrument or institutional record. | Non-empty. Do not reinterpret this field as a verified real-world citation. |
| `extract` | string | Yes | Controlled synthetic statement available to the learner. | Non-empty. Preserve wording when testing source traceability. |
| `authority` | string | Yes | Domain under which the evidence should be evaluated. | Must use one of the categories declared in the schema. |
| `verified` | boolean | Yes | Indicates that the supplied synthetic statement is approved for use in the exercise. | `true` does not validate later AI inferences derived from the statement. |

## Record-level controls

- `evidence_id` is the primary key.
- Duplicate identifiers are prohibited.
- Missing required fields stop notebook execution.
- Every AI-generated actor, asset, flow, risk or recommendation must cite one or more evidence identifiers or be labelled as reported or unknown.
- The `verified` field applies only to the supplied synthetic record. It does not make an AI interpretation authoritative.

## Human review boundary

The statistician defines the statistical purpose, concepts, quality criteria and acceptance decision. The relevant subject-matter specialist validates institutional meaning, operational practice and domain consequences. AI may organize or propose candidate records, but it may not approve the evidence, establish official authority or verify its own output.
