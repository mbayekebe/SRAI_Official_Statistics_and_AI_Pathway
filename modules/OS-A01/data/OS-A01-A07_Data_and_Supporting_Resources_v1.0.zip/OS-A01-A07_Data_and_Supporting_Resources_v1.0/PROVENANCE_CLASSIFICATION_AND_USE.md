# Provenance Classification and Approved Use

## Provenance

The Republic of Kintaba and every record in `kintaba_evidence_register.json` are synthetic. The dataset was created exclusively for the SRAI Official Statistics and AI Pathway Module OS-A01, The National Information Ecosystem. It contains no administrative microdata, survey responses, personal data, confidential statistical information or embargoed official figures.

## Information classification

| Control | Classification |
|---|---|
| Sensitivity | Synthetic training data |
| Personal data | None |
| Confidential unit records | None |
| Embargoed statistics | None |
| External AI use | Permitted only under the learner's approved training environment and institutional rules |
| Public interpretation | Must be identified as fictional and must not be represented as evidence about a real country |

## Approved use

The files may be used to execute the accompanying notebook, practise prompt construction, compare baseline and AI-assisted workflows, detect unsupported claims, correct candidate outputs, and produce the Module OS-A01 evidence-backed ecosystem map.

## Prohibited use

- Do not treat the records as observations about an actual country or institution.
- Do not use the dataset to train or evaluate a production model.
- Do not combine it with protected information and then submit the combined material to an unapproved AI service.
- Do not infer that AI output is verified merely because it refers to a valid `evidence_id`.
- Do not remove the synthetic-data notice from redistributed learning packages.

## Accountability

AI can accelerate extraction, organization, comparison and drafting. A qualified statistician must approve the statistical interpretation, and the relevant subject-matter specialist must confirm contextual and institutional meaning. Independent source checks, reproducible tests and documented corrections remain mandatory.
