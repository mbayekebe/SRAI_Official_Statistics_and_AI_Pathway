# OS-A01-A07 Data and Supporting Resources

## Purpose

This controlled asset supplies the synthetic data and documentation required by the Module OS-A01 canonical notebook. It implements asset class A07 under the SRAI Official Statistics and AI Pathway Production Reference version 1.3.

## Contents

| File | Purpose |
|---|---|
| `data/kintaba_evidence_register.json` | Ten synthetic evidence records used by the notebook. |
| `data/kintaba_evidence_register.schema.json` | Machine-readable structure and field constraints. |
| `DATA_DICTIONARY.md` | Field definitions, validation rules and human-review boundary. |
| `PROVENANCE_CLASSIFICATION_AND_USE.md` | Provenance, information classification, approved use and restrictions. |
| `OS-A01-A07_METADATA.json` | Controlled asset identity and relationship to Module OS-A01. |
| `OS-A01-A07_VALIDATION_REPORT.md` | Validation evidence and conformity decision. |
| `SHA256SUMS` | Integrity checksums for the package files. |

## Notebook placement

For the standard folder-based workflow, create a `data` directory beside the notebook and place `kintaba_evidence_register.json` inside it:

```text
module-a1/
  OS-A01-A01_Canonical_Notebook_The_National_Information_Ecosystem_v1.0.1.ipynb
  data/
    kintaba_evidence_register.json
```

The revised notebook also contains an identical embedded fallback so that it can execute as a standalone file. When the external file exists, the notebook records its path as the evidence source. When the fallback is used, the learner must still apply the same verification and human-approval rules.

## Required practice evidence

Learners must retain the task specification or prompt, candidate output, evidence identifiers used, detected errors, corrections, elapsed baseline and AI-assisted time, verification effort, residual limitations, and the statistician and subject-matter specialist disposition.

## Version

- Asset ID: OS-A01-A07
- Version: 1.0
- Status: controlled candidate
- Case: Republic of Kintaba synthetic case
