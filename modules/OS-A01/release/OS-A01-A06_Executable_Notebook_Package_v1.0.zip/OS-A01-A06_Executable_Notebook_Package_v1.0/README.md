# OS-A01-A06 Executable Notebook Package v1.0

The controlled laboratory companion to Module OS-A01, The National Information Ecosystem. The four practical workflows cover actor mapping, information assets, critical flows and an AI opportunity decision. Source lineage: validated standalone notebook v1.0.1.

## Run

Open the notebook from this package root and run all cells in order with Python 3 and the dependencies in `requirements.txt`. Outputs are written to `outputs/`. To run the notebook as a single file in VS Code, download the `.ipynb` alone: it includes an identical embedded synthetic evidence fallback when `data/` is absent.

The case is synthetic. AI candidate outputs are embedded so verification works offline. Live AI use requires institutional authorization, data classification and logging. The statistician and subject-matter specialist retain all professional and release decisions.
